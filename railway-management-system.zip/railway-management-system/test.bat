@echo off
title Run Railway Management System Tests
echo =====================================================================
echo Running JUnit 5 Test Suite
echo =====================================================================

set CP=bin;lib\postgresql-42.7.2.jar;lib\jbcrypt-0.4.jar;lib\flatlaf-3.4.jar

java -jar lib\junit-platform-console-standalone-1.10.2.jar --class-path "%CP%" --scan-class-path

echo.
pause
