# Railway Management System (RMS)
**Desktop Railway Simulation | Java OOP, Swing, JDBC, PostgreSQL & Maven**

---

## 1. Project Overview

The **Railway Management System (RMS)** is an educational simulation of a modern railway passenger portal and operations console. Built with clean **Java 17+**, **Java Swing**, and **PostgreSQL**, it demonstrates enterprise software design principles:

- **Layered Architecture**: Presentation (`gui`) $\to$ Business (`service`) $\to$ Data Access (`dao`) $\to$ PostgreSQL database.
- **ACID Transaction Integrity**: Concurrent seat allocation with `SELECT ... FOR UPDATE` and PostgreSQL partial unique indexes to guarantee zero double-booking.
- **Defensive Security**: Industry-standard BCrypt password hashing with work factor 12 and parameterized `PreparedStatement`s throughout.
- **Modern UI**: Styled with **FlatLaf Look and Feel** (Navy Blue & Slate aesthetic) for a contemporary desktop experience.
- **Human-Crafted Code**: Realistic domain models, authentic Indian Railways train numbers, station codes, travel classes, and clear architectural documentation.

---

## 2. Default Demo Accounts

| Role | Username | Password | Purpose |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin` | `Admin@123` | Fleet management, live platform reassignment, system audit trail |
| **Passenger** | `rahul` | `Rahul@123` | Train search, real-time availability, seat booking, ticket print preview |

*Note: New passenger accounts can also be registered directly from the application login screen.*

---

## 3. Database Setup (PostgreSQL)

### Quick Setup:
1. Ensure PostgreSQL is installed and running on port `5432`.
   - *If PostgreSQL is not yet installed on your machine, run `Install_PostgreSQL.exe` placed on your Desktop, set the password for user `postgres` to `root`, and complete installation.*
2. Create the database:
   ```sql
   CREATE DATABASE railway_db;
   ```
3. Check `src/main/resources/db.properties` (or `bin/db.properties`):
   ```properties
   db.driver=org.postgresql.Driver
   db.url=jdbc:postgresql://localhost:5432/railway_db
   db.user=postgres
   db.password=root
   ```
4. **Automatic Provisioning**: On first launch, RMS automatically detects missing tables and runs `schema.sql` and `sample_data.sql` to populate stations, trains, routes, and seats.

---

## 4. How to Run

### Option 1: Double-Click Launcher (Windows)
- Double-click **`run.bat`** in the project folder to start the application.
- To recompile changes at any time, double-click **`build.bat`**.
- To execute the JUnit 5 test suite, double-click **`test.bat`**.

### Option 2: Maven CLI
```bash
mvn clean compile exec:java
```

### Option 3: IDE (IntelliJ IDEA, Eclipse, or VS Code)
- Open the `railway-management-system` folder as a Maven project.
- Run `com.railway.Main.java`.

---

## 5. Object-Oriented Programming (OOP) Highlights

| OOP Principle | Implementation Details |
| :--- | :--- |
| **Abstraction** | `User.java` and `Train.java` are abstract base classes defining contract methods like `hasAdminPrivileges()` and `calculateBaseMultiplier()`. Interface contracts decouple services (`TrainService`) from data access (`TrainDAO`). |
| **Encapsulation** | Private member variables across domain models (`Seat`, `Reservation`, `Station`) accessed via validated getters, setters, and domain methods (`isCancellable()`). |
| **Inheritance** | `PassengerUser` and `AdminUser` inherit from `User`. `RajdhaniExpress`, `ShatabdiExpress`, and `MailExpressTrain` inherit from `Train`. |
| **Polymorphism** | `Train.calculateBaseMultiplier()` dynamically returns `1.50` for Rajdhani, `1.35` for Shatabdi, and `1.00` for standard express trains, eliminating hardcoded procedural switch statements in fare math. |
| **Composition** | `Reservation` *has-a* collection of `ReservationPassenger` entities; `Train` *has-a* collection of `RouteStop` entities. |

---

## 6. Directory Structure

```
railway-management-system/
├── pom.xml                                <-- Maven Project Configuration
├── run.bat                                <-- 1-Click Application Launcher
├── build.bat                              <-- 1-Click Compiler Script
├── test.bat                               <-- 1-Click JUnit 5 Test Runner
├── lib/                                   <-- Bundled JARs (PostgreSQL, FlatLaf, BCrypt, JUnit)
├── src/
│   ├── main/
│   │   ├── java/com/railway/
│   │   │   ├── Main.java                  <-- Application Entry Point
│   │   │   ├── config/                    <-- AppConfig & SessionContext
│   │   │   ├── database/                  <-- Connection Manager & SchemaInitializer
│   │   │   ├── model/                     <-- OOP Domain Hierarchy & Enums
│   │   │   ├── dao/                       <-- DAO Interfaces & PostgreSQL Implementations
│   │   │   ├── service/                   <-- Business Logic & Transaction Coordinators
│   │   │   ├── util/                      <-- PasswordUtil (BCrypt), PNRGenerator, FareCalculator
│   │   │   ├── exception/                 <-- Domain Checked Exceptions
│   │   │   └── gui/                       <-- Swing Dashboards, Dialogs & Panels
│   │   └── resources/
│   │       ├── db.properties              <-- Database Connection Settings
│   │       ├── schema.sql                 <-- PostgreSQL 14+ DDL Script
│   │       └── sample_data.sql            <-- Initial Seeds (Trains, Stations, Routes)
│   └── test/java/com/railway/             <-- JUnit 5 Unit Tests (100% Pass Rate)
└── bin/                                   <-- Compiled Bytecode & Resources
```
