@echo off
title Railway Management System
echo =====================================================================
echo Launching Railway Management System (Java Swing + PostgreSQL)
echo =====================================================================

set CP=bin;lib\postgresql-42.7.2.jar;lib\jbcrypt-0.4.jar;lib\flatlaf-3.4.jar

java -cp "%CP%" com.railway.Main

if %ERRORLEVEL% neq 0 (
    echo.
    echo Application exited with code %ERRORLEVEL%.
    pause
)
