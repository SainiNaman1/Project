package com.railway.database;

import com.railway.config.AppConfig;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Manages JDBC database connections to PostgreSQL.
 * Implements the SINGLETON pattern for centralized connection lifecycle
 * and transaction boundary management.
 */
public final class DatabaseConnection {

    private static volatile DatabaseConnection instance;

    static {
        try {
            AppConfig.init();
            Class.forName(AppConfig.getDbDriver());
        } catch (ClassNotFoundException e) {
            System.err.println("[DatabaseConnection] CRITICAL: PostgreSQL JDBC Driver not found: " + e.getMessage());
        }
    }

    private DatabaseConnection() {
    }

    public static DatabaseConnection getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnection.class) {
                if (instance == null) {
                    instance = new DatabaseConnection();
                }
            }
        }
        return instance;
    }

    /**
     * Obtains a fresh JDBC Connection to the PostgreSQL database.
     * The caller is responsible for closing the connection (typically via try-with-resources).
     */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                AppConfig.getDbUrl(),
                AppConfig.getDbUser(),
                AppConfig.getDbPassword()
        );
    }

    /**
     * Tests whether a database connection can be established.
     *
     * @return true if connection succeeds and is valid, false otherwise.
     */
    public boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && conn.isValid(2);
        } catch (SQLException e) {
            System.err.println("[DatabaseConnection] Test connection failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Safely rolls back an uncommitted transaction and suppresses any secondary SQL errors.
     */
    public static void rollbackQuietly(Connection conn) {
        if (conn != null) {
            try {
                if (!conn.getAutoCommit()) {
                    conn.rollback();
                }
            } catch (SQLException e) {
                System.err.println("[DatabaseConnection] Failed to rollback transaction: " + e.getMessage());
            }
        }
    }

    /**
     * Resets auto-commit to true and closes the connection safely.
     */
    public static void closeQuietly(Connection conn) {
        if (conn != null) {
            try {
                if (!conn.getAutoCommit()) {
                    conn.setAutoCommit(true);
                }
                conn.close();
            } catch (SQLException e) {
                // Ignore closing error
            }
        }
    }
}
