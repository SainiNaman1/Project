package com.railway.database;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.stream.Collectors;

/**
 * Automates initial schema creation and sample data provisioning.
 * If the 'users' table is not detected, it executes schema.sql followed by sample_data.sql.
 */
public final class SchemaInitializer {

    private SchemaInitializer() {
    }

    /**
     * Initializes the database if tables do not exist.
     */
    public static synchronized void initializeDatabase() {
        DatabaseConnection db = DatabaseConnection.getInstance();
        try (Connection conn = db.getConnection()) {
            if (!tablesExist(conn)) {
                System.out.println("[SchemaInitializer] Database tables not detected. Initializing schema...");
                executeSqlScript(conn, "schema.sql");
                System.out.println("[SchemaInitializer] Schema initialized successfully. Seeding sample data...");
                executeSqlScript(conn, "sample_data.sql");
                System.out.println("[SchemaInitializer] Sample data seeded successfully.");
            } else {
                System.out.println("[SchemaInitializer] Database schema already exists. Skipping initialization.");
            }
        } catch (SQLException e) {
            System.err.println("[SchemaInitializer] Note on schema initialization: " + e.getMessage());
        }
    }

    private static boolean tablesExist(Connection conn) throws SQLException {
        DatabaseMetaData meta = conn.getMetaData();
        try (ResultSet rs = meta.getTables(null, "public", "users", new String[]{"TABLE"})) {
            return rs.next();
        }
    }

    private static void executeSqlScript(Connection conn, String resourcePath) {
        try (InputStream is = SchemaInitializer.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (is == null) {
                System.err.println("[SchemaInitializer] Resource file not found: " + resourcePath);
                return;
            }

            String fullSql = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))
                    .lines()
                    .collect(Collectors.joining("\n"));

            // Split into individual SQL statements by semicolon
            // Basic delimiter handling for scripts without stored procedures
            String[] statements = fullSql.split(";\\s*(\\r?\\n)+");

            try (Statement stmt = conn.createStatement()) {
                for (String rawSql : statements) {
                    String sql = rawSql.trim();
                    if (!sql.isEmpty() && !sql.startsWith("--")) {
                        try {
                            stmt.execute(sql);
                        } catch (SQLException e) {
                            // Log but continue for idempotent clauses like ON CONFLICT
                            System.err.println("[SchemaInitializer] Statement notice: " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[SchemaInitializer] Failed executing SQL script " + resourcePath + ": " + e.getMessage());
        }
    }
}
