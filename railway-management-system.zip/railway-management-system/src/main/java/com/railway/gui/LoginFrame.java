package com.railway.gui;

import com.railway.exception.AuthenticationException;
import com.railway.model.User;
import com.railway.model.enums.Role;
import com.railway.service.AuthService;
import com.railway.service.impl.AuthServiceImpl;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

/**
 * Main application authentication window.
 * Routes authenticated passengers to PassengerDashboard and administrators to AdminDashboard.
 */
public class LoginFrame extends JFrame {

    private final AuthService authService;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JLabel lblStatus;

    public LoginFrame() {
        this.authService = new AuthServiceImpl();
        initUI();
    }

    private void initUI() {
        setTitle("Railway Management System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(480, 520);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout());

        // Header Banner
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(UITheme.PRIMARY_NAVY);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(24, 16, 24, 16));
        headerPanel.setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("INDIAN RAILWAYS SIMULATION", SwingConstants.CENTER);
        lblTitle.setFont(UITheme.FONT_TITLE);
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSubtitle = new JLabel("Educational Desktop Passenger Portal", SwingConstants.CENTER);
        lblSubtitle.setFont(UITheme.FONT_BODY);
        lblSubtitle.setForeground(new Color(203, 213, 225));

        headerPanel.add(lblTitle, BorderLayout.CENTER);
        headerPanel.add(lblSubtitle, BorderLayout.SOUTH);
        add(headerPanel, BorderLayout.NORTH);

        // Center Login Card
        JPanel centerContainer = new JPanel(new GridBagLayout());
        centerContainer.setBackground(new Color(241, 245, 249));

        JPanel card = UITheme.createCardPanel();
        card.setLayout(new GridBagLayout());
        card.setPreferredSize(new Dimension(380, 320));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        // Card Title
        JLabel lblLoginHeader = new JLabel("Account Sign In");
        lblLoginHeader.setFont(UITheme.FONT_HEADER);
        lblLoginHeader.setForeground(UITheme.TEXT_DARK);
        gbc.gridy = 0;
        card.add(lblLoginHeader, gbc);

        // Username Field
        JLabel lblUser = new JLabel("Username");
        lblUser.setFont(UITheme.FONT_BODY_BOLD);
        gbc.gridy = 1;
        card.add(lblUser, gbc);

        txtUsername = new JTextField(20);
        txtUsername.setFont(UITheme.FONT_BODY);
        gbc.gridy = 2;
        card.add(txtUsername, gbc);

        // Password Field
        JLabel lblPass = new JLabel("Password");
        lblPass.setFont(UITheme.FONT_BODY_BOLD);
        gbc.gridy = 3;
        card.add(lblPass, gbc);

        txtPassword = new JPasswordField(20);
        txtPassword.setFont(UITheme.FONT_BODY);
        gbc.gridy = 4;
        card.add(txtPassword, gbc);

        // Status Error Label
        lblStatus = new JLabel(" ");
        lblStatus.setFont(UITheme.FONT_SMALL);
        lblStatus.setForeground(UITheme.ACCENT_RED);
        gbc.gridy = 5;
        card.add(lblStatus, gbc);

        // Login Button
        JButton btnLogin = UITheme.createPrimaryButton("Sign In");
        gbc.gridy = 6;
        card.add(btnLogin, gbc);

        // Register Button
        JButton btnRegister = new JButton("Create New Passenger Account");
        btnRegister.setFont(UITheme.FONT_BODY);
        btnRegister.setFocusPainted(false);
        gbc.gridy = 7;
        card.add(btnRegister, gbc);

        centerContainer.add(card);
        add(centerContainer, BorderLayout.CENTER);

        // Event Listeners
        btnLogin.addActionListener(e -> performLogin());
        txtPassword.addActionListener(e -> performLogin());
        txtUsername.addActionListener(e -> txtPassword.requestFocusInWindow());

        btnRegister.addActionListener(e -> {
            RegisterFrame regFrame = new RegisterFrame(this, authService);
            regFrame.setVisible(true);
        });
    }

    private void performLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        lblStatus.setText("Authenticating...");
        SwingUtilities.invokeLater(() -> {
            try {
                User user = authService.login(username, password);
                lblStatus.setText("Login successful!");

                dispose(); // Close login window
                if (user.getRole() == Role.ADMIN) {
                    new AdminDashboard().setVisible(true);
                } else {
                    new PassengerDashboard().setVisible(true);
                }
            } catch (AuthenticationException ex) {
                lblStatus.setText(ex.getMessage());
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Authentication Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
